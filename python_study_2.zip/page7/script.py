fruits = {'apel': 'apple', 'jeruk': 'orange', 'anggur': 'grape'}

# Dengan loop for, cetak '___ adalah ___ dalam bahasa Inggris'
for fruit_key in fruits:
    print(fruit_key + ' adalah ' +fruits[fruit_key] +  ' dalam bahasa Inggris')
