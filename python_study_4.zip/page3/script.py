class MenuItem:
    pass


# Buat instance untuk class MenuItem 
menu_item1 = MenuItem()
